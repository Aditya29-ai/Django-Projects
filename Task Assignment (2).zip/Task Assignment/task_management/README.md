<!-- Project Setup  -->

1. Create the Project

django-admin startproject task_management
cd task_management

2. Start the App

python manage.py startapp API

<!-- End Project Setup  -->



<!-- Model Setup  -->

1. Model Setup

a. User: Represents users with fields for name, email, and mobile.

b. Task: Represents tasks with name, description, status, and assigned users.


2. Make Migrations

python manage.py makemigrations

3. Apply Migrations

python manage.py migrate

<!-- End Model Setup -->




<!--  Serializers and Admin Configuration  -->

1. Create serializers.py:

Serializers for User, Task, and AssignTask to handle data conversion.

2. Configure admin.py:

Register models with search and list display features for better admin panel management.

3. Create Superuser
 
python manage.py createsuperuser

<!-- End Serializers and Admin Configuration  -->



<!-- API Endpoints -->



<!-- This is for User Creation -->
1.  User APIs

Create User

URL: http://127.0.0.1:8000/API/users/

Method: POST

Request Body:

{
    "name": "Wipro Limited",
    "email": "wipro@yopmail.com",
    "mobile": "1234567890"
}


Response:

{
    "id": 4,
    "created_at": "2025-03-25",
    "name": "Wipro Limited",
    "email": "wipro@yopmail.com",
    "mobile": "1234567890"
}
<!-- End for User API -->



<!-- Create Task API -->


2. Create Task

URL: http://127.0.0.1:8000/API/create-task/

Method: POST

Request Body:

{
    "name": "Pending Project Works",
    "description": "You need to Develope and testing APIS",
    "task_type": "Developer End",
    "status": "pending",
    "users": [1,2] 
  
}


Response :

{
    "id": 24,
    "name": "Pending Project Works",
    "description": "You need to Develope and testing APIS",
    "created_at": "2025-03-25",
    "completed_at": null,
    "task_type": "Developer End",
    "status": "pending",
    "users": [
        {
            "id": 1,
            "created_at": "2025-03-24",
            "name": "Admin",
            "email": "admin@gmail.com",
            "mobile": "0987654321"
        },
        {
            "id": 2,
            "created_at": "2025-03-24",
            "name": "Aditya",
            "email": "a@gmail.com",
            "mobile": "9011574444"
        }
    ]
}

<!-- End of Create Task API -->





<!-- Assign Task API -->

3. Assign Task

URL: http://127.0.0.1:8000/API/assign-task/

Method: POST

Request Body:

{
    "task_id": 20,         // The ID of the task you want to assign users to
    "user_ids": [1,4]  // List of existing user IDs
}

Response:

{
    "message": "Task assigned successfully"
}

<!-- End Assign Task API  -->




<!-- Get User Tasks API  -->


4. User Task

URL: http://127.0.0.1:8000/API/user-tasks/4/

Method: GET

Response:

[
    {
        "id": 20,
        "name": "Done API",
        "description": "Manage a Django REST Framework API",
        "created_at": "2025-03-24",
        "completed_at": null,
        "task_type": "Production",
        "status": "in_progress",
        "users": [
            {
                "id": 1,
                "created_at": "2025-03-24",
                "name": "Admin",
                "email": "admin@gmail.com",
                "mobile": "0987654321"
            },
            {
                "id": 4,
                "created_at": "2025-03-25",
                "name": "Wipro Limited",
                "email": "wipro@yopmail.com",
                "mobile": "1234567890"
            }
        ]
    }
]

<!-- End Of User API -->




<!-- Admin Panel  -->

5. Admin Panel

URL: http://127.0.0.1:8000/admin/

Use the following credentials to access the admin panel:

Username: admin
Password: 1234

Use the superuser credentials to access the admin panel and manage User and Task models.



<!-- End Admin panel -->










