from django.views import View
from django.shortcuts import render, redirect
from .models import Student
import csv
from django.http import HttpResponse
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from openpyxl import Workbook
from django.contrib.auth import authenticate, login ,logout
from django.contrib import messages
from django.contrib.auth.models import User
from django.core.paginator import Paginator
from django.db.models import Q


class CustomSignUpView(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Create user
        if User.objects.filter(username=username).exists():
            messages.error(request, 'Username already exists!')
            return render(request, 'signup.html')
        
        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()

        # Success message and redirect to login page
        messages.success(request, 'User created successfully! Please log in.')
        return redirect('login')  # Replace with your login URL name



    

class CustomLoginView(View):
    def get(self, request):
        return render(request, 'login.html')

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')

        print(f"Trying to authenticate user: {username}")  # Debugging print
        user = authenticate(request, username=username, password=password)
        if user is not None:
            print("User authenticated successfully.")  # Debugging print
            login(request, user)
            return redirect('student_form')
        else:
            print("Invalid username or password.")  # Debugging print
            messages.error(request, 'Invalid username or password')
            return render(request, 'login.html')
class CustomLogoutView(View):
    def get(self, request):
        logout(request)
        return redirect('login')  # Redirect to login page after logout

class StudentView(View):
    def get(self, request):
        print('xyz')
        # Ensure only authenticated users can access the page
        if request.user.is_authenticated:
            # Handle search query if present
            search_query = request.GET.get('search', '')
            # Filter students based on the search query
            students = Student.objects.filter(
                user=request.user
            ).filter(
                Q(name__icontains=search_query) | 
                Q(student_class__icontains=search_query) |
                Q(roll_no__icontains=search_query)
            )
            
            # Paginate students
            paginator = Paginator(students, 10)  # Show 10 students per page
            page_number = request.GET.get('page')
            page_obj = paginator.get_page(page_number)

            # Debugging print to check the students fetched
            print(f"Students found: {page_obj.object_list}")

            return render(request, 'student_form.html', {
                'student': page_obj,  # Pass the paginated students
                'search_query': search_query,  # Pass the search query to the template
            })
        else:
            return redirect('login')

    def post(self, request):
        print('abc')
        name = request.POST.get('name')
        age = request.POST.get('age')
        student_class = request.POST.get('student_class')
        roll_no = request.POST.get('roll_no')

        if request.user.is_authenticated:
            # Save the student and associate with the logged-in user
            student = Student.objects.create(
                user=request.user,  # Associate the student with the logged-in user
                name=name,
                age=age,
                student_class=student_class,
                roll_no=roll_no
            )
            print(f"Student created: {student.name}")  # Debugging print
            return redirect('student_form')  # Redirect to the same form page after saving the student
        else:
            return redirect('login')  # If the user is not authenticated, redirect to login
    

def export_csv(request):
    if not request.user.is_authenticated:
        return redirect('login')

    students = Student.objects.filter(user=request.user)

    wb = Workbook()
    ws = wb.active
    ws.title = "Student List"

    ws.merge_cells('A1:D1')
    ws['A1'] = 'Student List'
    ws.append([])

    ws.append(['Name', 'Age', 'Class', 'Roll No'])

    for student in students:
        ws.append([student.name, student.age, student.student_class, student.roll_no])

    response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
    response['Content-Disposition'] = 'attachment; filename=students.xlsx'

    wb.save(response)
    return response


    
def export_pdf(request):
    if not request.user.is_authenticated:
        return redirect('login')

    students = Student.objects.filter(user=request.user)

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="students.pdf"'

    p = canvas.Canvas(response, pagesize=letter)

    p.setFont("Helvetica-Bold", 16)
    p.drawCentredString(300, 770, "Student List")

    p.setFont("Helvetica-Bold", 12)
    y_position = 740
    p.drawString(100, y_position, "Name")
    p.drawString(200, y_position, "Age")
    p.drawString(250, y_position, "Class")
    p.drawString(320, y_position, "Roll No")

    p.setFont("Helvetica", 12)
    y_position -= 20
    for student in students:
        p.drawString(100, y_position, student.name)
        p.drawString(200, y_position, str(student.age))
        p.drawString(250, y_position, student.student_class)
        p.drawString(320, y_position, student.roll_no)
        y_position -= 20

        if y_position < 50:
            p.showPage()
            y_position = 770
            p.setFont("Helvetica", 12)

    p.showPage()
    p.save()
    return response

