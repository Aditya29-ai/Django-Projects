from django.db import models
from django.contrib.auth.models import User

# Profile model to extend User with additional fields
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    resume = models.FileField(upload_to='resumes/', blank=True, null=True)  

    def __str__(self):
        return f"{self.user.username}'s Profile"
    
    DisplayList = ['id','user', 'resume']
    searchable_fields = ['id','user', 'resume']

# Category model
class Category(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name
    
    DisplayList = ['id','name'] 
    searchable_fields = ['id','name']
    
    
    

# Subcategory model linked to Category
class Subcategory(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='subcategories')
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name
    
    DisplayList = ['id','category', 'name']  
    
    searchable_fields = ['id','category', 'name']

# Product model with category, subcategory, and product details
class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    subcategory = models.ForeignKey(Subcategory, on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    cost = models.DecimalField(max_digits=10, decimal_places=2)
    discount = models.DecimalField(max_digits=5, decimal_places=2)
    color = models.CharField(max_length=50)

    def __str__(self):
        return self.name
    

    DisplayList = ['id','category', 'subcategory', 'name', 'cost', 'discount', 'color'] 
    searchable_fields = ['id','category', 'subcategory', 'name', 'cost', 'discount', 'color']


class ProductImage(models.Model):
    product = models.ForeignKey(Product, related_name='images', on_delete=models.CASCADE)
    image = models.ImageField(upload_to='product_images/')

    DisplayList = ['id','image'] 
    searchable_fields = ['id']
    

