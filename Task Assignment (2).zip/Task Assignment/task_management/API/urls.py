from django.urls import path
from .views import *

urlpatterns = [
    path('users/', UserCreateView.as_view(), name='user-create'),                      # POST -> Create User
    path('create-task/', TaskCreateView.as_view(), name='create-task'),                # POST -> Create task
    path('assign-task/', AssignTaskView.as_view(), name='assign-task'),                # POST -> Assign task to users
    path('user-tasks/<int:user_id>/', UserTasksView.as_view(), name='user-tasks'),    # GET -> Retrieve tasks for a user
]
