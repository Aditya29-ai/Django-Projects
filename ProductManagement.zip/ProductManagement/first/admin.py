from django.contrib import admin
from .models import *

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = Category.DisplayList
    search_fields = ['id', 'name']  # List of fields to search

@admin.register(Subcategory)
class SubcategoryAdmin(admin.ModelAdmin):
    list_display = Subcategory.DisplayList
    search_fields = ['id', 'category__name', 'name']  # List of fields to search, use '__' to refer to related fields

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = Product.DisplayList
    search_fields = ['id', 'category__name', 'subcategory__name', 'name', 'cost', 'discount', 'color']  # List of fields to search


@admin.register(ProductImage)
class ProductImageAdmin(admin.ModelAdmin):
    list_display = ProductImage.DisplayList
    search_fields = ['id']  # List of fields to search

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = UserProfile.DisplayList
    search_fields = ['id','user']  # List of fields to search

