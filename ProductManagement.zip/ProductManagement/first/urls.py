from django.urls import path
from .views import *

urlpatterns = [
    
    path('', IndexView.as_view(), name='index'),  # Assuming index_view is defined as the main page view
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', UserLogoutView.as_view(), name='logout'),
    path('signup/', SignUpView.as_view(), name='signup'),  # Correct the spelling here
    path('upload_resume/', UploadResumeView.as_view(), name='upload_resume'),
    path('prouduct_form/',ProductView.as_view(),name='product_form'),
    path('get_subcategories/', get_subcategories, name='get_subcategories'),  # Add this line
    path('category_list/',CategoryView.as_view(),name='category_list'),
    path('subcategory_list/', SubcategoryView.as_view(), name='subcategory_list'),
    path('products/export_pdf/', ProductView.as_view(), name='export_pdf'),

    
    
    


]
