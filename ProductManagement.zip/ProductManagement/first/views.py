

################################## essential imports #######################################



from django.shortcuts import render, redirect # this is for page redirect render
from django.contrib.auth import authenticate, login as auth_login, logout # this is for user login logout
from django.views import View # this for view
from django.contrib import messages # this for error , succes messages
from django.urls import reverse # this for page reverse
from django.contrib.auth.models import User # this is for model import
from .models import * # import all models
from django.http import JsonResponse # this is for jsonResponse  usefull for ajax or api response
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger # this is for paginator
from django.db.models import Q # this is for search 
from django.utils.decorators import method_decorator # this is validation for link copy paste
from django.contrib.auth.mixins import LoginRequiredMixin # this is validation for link copy paste
from django.views.decorators.cache import cache_control #this is validation for link copy paste

from django.http import HttpResponse
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from io import BytesIO
from reportlab.lib.utils import ImageReader



################################## Login ################################################
class LoginView(View):
    def get(self, request):
        return render(request, 'admin_template/login.html')

    def post(self, request):
        email = request.POST.get("email")
        password = request.POST.get("password")

        # Authenticate using email as the username field
        user = authenticate(request, username=email, password=password)

        if user is not None:
            # If you want to allow only superusers or regular users based on your requirement
            if user.is_superuser:
                auth_login(request, user)
                print(f"Authenticated Superuser: {user.username}")
                return redirect('upload_resume')  # Redirect to the admin dashboard
            else:
                auth_login(request, user)
                print(f"Authenticated User: {user.username}")
                return redirect('upload_resume')  # Redirect to the user dashboard
        else:
            messages.error(request, "Invalid username or password")
        
        return render(request, 'admin_template/login.html')


############################################## Signup #################################################
class SignUpView(View):
    def get(self, request):
        # Display the signup form
        return render(request, 'admin_template/signup.html')

    def post(self, request):
    # Handle form submission for creating a new user
        email = request.POST.get('email')
        password = request.POST.get('password')
        username = request.POST.get('username')
        
        # Check if the email or username already exists
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email is already registered")
            return render(request, 'admin_template/signup.html')
        
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username is already taken")
            return render(request, 'admin_template/signup.html')
        
        # Create a new user
        try:
            user = User.objects.create_user(username=username, email=email, password=password)
            user.save()

            # Explicitly pass the backend when logging in
            user.backend = 'first.backends.EmailBackend'  # Set the backend manually
            auth_login(request, user)

            messages.success(request, "Signup successful. You can now login.")
            return redirect('login') # Redirect to the login page after successful signup
        except Exception as e:
            messages.error(request, f"Error occurred during signup: {e}")
            return render(request, 'admin_template/signup.html')


########################################## LogOut ###################################################
class UserLogoutView(View):
    def get(self, request):
        logout(request)
        return redirect('login')
    
############################################ Upload Resume After Login #################################################
class UploadResumeView(LoginRequiredMixin,View):

    @method_decorator(cache_control(no_cache=True, must_revalidate=True, no_store=True))  
    def get(self, request):
        return render(request, 'admin_template/upload_resume.html')

    
    def post(self, request):
        resume = request.FILES.get('resume')

        # Check if the user already has a profile
        user_profile, created = UserProfile.objects.get_or_create(user=request.user)

        if resume:
            user_profile.resume = resume
            user_profile.save()
            messages.success(request, "Resume uploaded successfully.")
        else:
            messages.error(request, "Please upload a valid resume.")

        return redirect('index') 
    

    
################################### After Upload Resume It is redirect to this page  ############################################

class IndexView(LoginRequiredMixin,View):
    @method_decorator(cache_control(no_cache=True, must_revalidate=True, no_store=True))    
    def get(self, request):
        # Display the index page with user information
        return render(request, 'admin_template/index.html')


################################# Category #############################################

class CategoryView(LoginRequiredMixin,View):
    @method_decorator(cache_control(no_cache=True, must_revalidate=True, no_store=True))    
    def get(self, request):
        search_query = request.GET.get("q", "")
        if search_query:
            categories = Category.objects.filter(
                Q(name__icontains=search_query)
            )
        else:
            categories = Category.objects.all()
        
        # Paginator
        paginator = Paginator(categories, 10)  # Show 10 items per page
        page = request.GET.get('page')
        try:
            categories = paginator.page(page)
        except PageNotAnInteger:
            categories = paginator.page(1)
        except EmptyPage:
            categories = paginator.page(paginator.num_pages)
        
        return render(request, 'admin_template/category_list.html', {
            'categories': categories,
            'search_query': search_query,
        })
    
    def post(self, request):
        name = request.POST.get('name')
        
        # Validate the form data
        if not name:
            messages.error(request, "Category name is required.")
            return redirect('category_list')  # Redirect to the same view
        
        # Create new Category instance
        Category.objects.create(name=name)
        messages.success(request, "Category added successfully.")
        return redirect('category_list')
    

############################################ Sub Category ######################################################

class SubcategoryView(LoginRequiredMixin,View):
    @method_decorator(cache_control(no_cache=True, must_revalidate=True, no_store=True))    
    def get(self, request):
        search_query = request.GET.get("q", "")
        if search_query:
            subcategories = Subcategory.objects.filter(
                Q(name__icontains=search_query) |
                Q(category__name__icontains=search_query)
            )
        else:
            subcategories = Subcategory.objects.all()
        
        # Paginator
        paginator = Paginator(subcategories, 10)  # Show 10 items per page
        page = request.GET.get('page')
        try:
            subcategories = paginator.page(page)
        except PageNotAnInteger:
            subcategories = paginator.page(1)
        except EmptyPage:
            subcategories = paginator.page(paginator.num_pages)

        # Pass categories for the dropdown in the form
        categories = Category.objects.all()

        return render(request, 'admin_template/subcategory_list.html', {
            'subcategories': subcategories,
            'search_query': search_query,
            'categories': categories,  # Pass categories here
        })

    
    def post(self, request):
        name = request.POST.get('name')
        category_id = request.POST.get('category')
        
        # Validate the form data
        if not name or not category_id:
            messages.error(request, "Both category and subcategory name are required.")
            return redirect('subcategory_list')  # Redirect to the same view
        
        # Create new Subcategory instance
        category = Category.objects.get(id=category_id)
        Subcategory.objects.create(name=name, category=category)
        messages.success(request, "Subcategory added successfully.")
        return redirect('subcategory_list')
      
################################################## Product ##########################################################  

class ProductView(LoginRequiredMixin,View):
    @method_decorator(cache_control(no_cache=True, must_revalidate=True, no_store=True))    
    def get(self, request):
        if request.GET.get("export") == "pdf":
            return self.export_pdf(request)
        # Initialize the categories, subcategories, and products
        categories = Category.objects.all()
        subcategories = []  # Empty list for subcategories
        if 'category' in request.GET:
            category_id = request.GET['category']
            subcategories = Subcategory.objects.filter(category_id=category_id)
            
        # Handle search functionality
        search_query = request.GET.get("q", "")  # Default empty if no query
        products = Product.objects.all()
        
        
        if search_query:
            products = products.filter(
                Q(name__icontains=search_query) |
                Q(category__name__icontains=search_query) |
                Q(subcategory__name__icontains=search_query) |
                Q(color__icontains=search_query) |
                Q(discount__icontains=search_query) |
                Q(cost__icontains=search_query)
            )
        
        # Pagination
        paginator = Paginator(products, 10)  # Show 10 items per page
        page = request.GET.get('page')
        try:
            products = paginator.page(page)
        except PageNotAnInteger:
            products = paginator.page(1)
        except EmptyPage:
            products = paginator.page(paginator.num_pages)

        # Render the template with categories, subcategories, products, and pagination
        return render(request, 'admin_template/product_form.html', {
            'categories': categories,
            'subcategories': subcategories,
            'products': products,
            'search_query': search_query
        })

    def post(self, request):
        category_id = request.POST.get('category')
        subcategory_id = request.POST.get('subcategory')
        name = request.POST.get('name')
        cost = request.POST.get('cost')
        discount = request.POST.get('discount')
        color = request.POST.get('color')
        images = request.FILES.getlist('images')

        try:
            category = Category.objects.get(id=category_id)
            subcategory = Subcategory.objects.get(id=subcategory_id)

            # Create the product
            product = Product(
                category=category,
                subcategory=subcategory,
                name=name,
                cost=cost,
                discount=discount,
                color=color,
            )
            product.save()

            # Saving multiple images
            for image in images:
                ProductImage.objects.create(product=product, image=image)  # Saving each image

            messages.success(request, "Product added successfully.")
        except Exception as e:
            messages.error(request, f"Error adding product: {str(e)}")
        
        return redirect('product_form')
    
    def export_pdf(self, request):
        # Create a BytesIO buffer to store the PDF
        buffer = BytesIO()
        # Create a canvas for the PDF
        pdf_canvas = canvas.Canvas(buffer, pagesize=A4)
        
        # Set title and starting position for content
        pdf_canvas.setFont("Helvetica-Bold", 18)
        pdf_canvas.drawString(200, 800, "Product List")
        
        # Set the starting y position for product listing
        y = 750
        products = Product.objects.all()
        
        # Loop through products and write details to PDF in table-like format
        for product in products:
            # Add product image if available
            images = ProductImage.objects.filter(product=product)
            if images.exists():
                try:
                    # Use the first image of the product as thumbnail
                    img = ImageReader(images[0].image.path)
                    pdf_canvas.drawImage(img, 50, y - 80, width=100, height=100)
                except Exception as e:
                    print(f"Could not add image for product {product.name}: {e}")

            # Add product details next to the image
            x_offset = 160  # Offset to position text beside the image
            pdf_canvas.setFont("Helvetica-Bold", 12)
            pdf_canvas.drawString(x_offset, y, f"Name: {product.name}")
            pdf_canvas.setFont("Helvetica", 10)
            pdf_canvas.drawString(x_offset, y - 15, f"Category: {product.category.name}")
            pdf_canvas.drawString(x_offset, y - 30, f"Subcategory: {product.subcategory.name}")
            pdf_canvas.drawString(x_offset, y - 45, f"Cost: {product.cost}")
            pdf_canvas.drawString(x_offset, y - 60, f"Discount: {product.discount}")
            pdf_canvas.drawString(x_offset, y - 75, f"Color: {product.color}")
            
            # Adjust y position for next product
            y -= 140  # Adjust space between products

            # Check if we need to create a new page
            if y < 100:
                pdf_canvas.showPage()
                y = 750

        # Finalize the PDF and close the canvas
        pdf_canvas.save()
        
        # Set response for the PDF download
        buffer.seek(0)
        response = HttpResponse(buffer, content_type='application/pdf')
        response['Content-Disposition'] = 'attachment; filename="products.pdf"'
        return response
    


    


# Add this method to your ProductView class or create a new view for AJAX
def get_subcategories(request):
    category_id = request.GET.get('category_id')
    
    # Check if category_id is provided
    if category_id:
        subcategories = Subcategory.objects.filter(category_id=category_id)
        subcategory_data = [{'id': subcategory.id, 'name': subcategory.name} for subcategory in subcategories]
        return JsonResponse({'subcategories': subcategory_data})
    
    # Return an empty list if no category_id provided
    return JsonResponse({'subcategories': []})



#################################################### End ############################################################
