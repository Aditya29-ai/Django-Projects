from rest_framework import serializers
from .models import User, Task



class UserSerializer(serializers.ModelSerializer):
    created_at = serializers.SerializerMethodField()  # Display date only

    class Meta:
        model = User
        fields = '__all__'

    def get_created_at(self, obj):
        return obj.created_at.date() if obj.created_at else None  # Display YYYY-MM-DD



class TaskSerializer(serializers.ModelSerializer):
    users = UserSerializer(many=True, read_only=True)
    created_at = serializers.SerializerMethodField()    # Display date only
    completed_at = serializers.SerializerMethodField()  # Display date only

    class Meta:
        model = Task
        fields = [
            'id', 'name', 'description', 'created_at', 'completed_at',
            'task_type', 'status', 'users'
        ]

    def get_created_at(self, obj):
        return obj.created_at.date() if obj.created_at else None  # Display YYYY-MM-DD

    def get_completed_at(self, obj):
        return obj.completed_at.date() if obj.completed_at else None  # Display YYYY-MM-DD

class AssignTaskSerializer(serializers.Serializer):
    task_id = serializers.IntegerField()
    user_ids = serializers.ListField(
        child=serializers.IntegerField()
    )
