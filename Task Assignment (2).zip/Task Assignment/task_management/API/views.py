from rest_framework import status
from rest_framework.views import APIView
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .models import *
from .serializers import *



# API to create a user (POST)
class UserCreateView(APIView):
    def post(self, request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# API to create a task (POST)
class TaskCreateView(APIView):

     def post(self, request):
        users_ids = request.data.pop('users', [])  # Extract users from data

        serializer = TaskSerializer(data=request.data)
        if serializer.is_valid():
            task = serializer.save()  # Save the task first

            # Add users to the task
            if users_ids:
                users = User.objects.filter(id__in=users_ids)
                task.users.set(users)

            return Response(TaskSerializer(task).data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# API to assign a task to one or multiple users (POST)
class AssignTaskView(APIView):

    def post(self, request):
        serializer = AssignTaskSerializer(data=request.data)

        if serializer.is_valid():
            task_id = serializer.validated_data['task_id']
            user_ids = serializer.validated_data['user_ids']

            task = get_object_or_404(Task, id=task_id)
            users = User.objects.filter(id__in=user_ids)

            if not users.exists():
                return Response({'error': 'No valid users found'}, status=status.HTTP_404_NOT_FOUND)

            task.users.set(users)
            return Response({'message': 'Task assigned successfully'}, status=status.HTTP_200_OK)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# API to get all tasks assigned to a specific user (GET)
class UserTasksView(APIView):

    def get(self, request, user_id):
        user = get_object_or_404(User, id=user_id)
        tasks = user.tasks.all()

        if not tasks.exists():
            return Response({'message': 'No tasks found for this user'}, status=status.HTTP_404_NOT_FOUND)

        serializer = TaskSerializer(tasks, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
